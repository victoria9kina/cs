error_reporting(E_ALL);
ini_set('display_errors', 1);

<?php
$servername = "localhost";
$username = "root"; // Убедитесь, что имя пользователя и пароль MySQL верны
$password = "12345678"; // Пароль для root пользователя
$dbname = "feedback"; // Название вашей базы данных

// Создаем подключение
$conn = new mysqli($servername, $username, $password, $dbname);

// Проверяем подключение
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Подготавливаем и выполняем SQL запрос
$name = $conn->real_escape_string($_POST['name']);
$email = $conn->real_escape_string($_POST['email']);
$message = $conn->real_escape_string($_POST['message']);
$sql = "INSERT INTO feedback (name, email, message) VALUES ('$name', '$email', '$message')";

if ($conn->query($sql) === TRUE) {
    echo "Запись успешно сохранена";
} else {
    echo "Ошибка: " . $sql . "<br>" . $conn->error;
}

// Закрываем подключение
$conn->close();
?>
