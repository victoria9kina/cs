<?php
$mysql = new mysqli('localhost', 'root', 'root', 'fb');

if ($mysql->connect_error) {
    die('Ошибка подключения (' . $mysql->connect_errno . ') ' . $mysql->connect_error);
}

$result = $mysql->query("SELECT `name`, `email`, `message` FROM `ms`");
$feedbacks = [];
while ($row = $result->fetch_assoc()) {
    $feedbacks[] = $row;
}
$mysql->close();

if (count($feedbacks) > 0) {
    foreach ($feedbacks as $fb) {
        echo '<div class="feedback">';
        echo '<h3>' . htmlspecialchars($fb['name']) . '</h3>';
        echo '<p>' . htmlspecialchars($fb['email']) . '</p>';
        echo '<p>' . htmlspecialchars($fb['message']) . '</p>';
        echo '</div>';
    }
} else {
    echo '<p>Нет сообщений.</p>';
}
?>
