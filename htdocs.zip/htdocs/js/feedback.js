document.addEventListener('DOMContentLoaded', () => {
    const feedbackForm = document.getElementById('feedback-form');
    const feedbackContainer = document.getElementById('feedback-container');

    feedbackForm.addEventListener('submit', function(event) {
        event.preventDefault();
        const formData = new FormData(feedbackForm);

        fetch('check.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.text())
        .then(data => {
            // Перезагрузка контейнера с отзывами
            loadFeedback();
            feedbackForm.reset();
        })
        .catch(error => console.error('Error:', error));
    });

    // Функция для загрузки отзывов
    function loadFeedback() {
        fetch('load_feedback.php')
        .then(response => response.text())
        .then(data => {
            feedbackContainer.innerHTML = data;
        })
        .catch(error => console.error('Error:', error));
    }

    // Загрузка отзывов при загрузке страницы
    loadFeedback();
});
