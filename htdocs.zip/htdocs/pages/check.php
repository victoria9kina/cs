<?php
// Получение и фильтрация данных из формы
$name = filter_var(trim($_POST['name']));
$email = filter_var(trim($_POST['email']));
$message = filter_var(trim($_POST['message']));

// Проверка длины данных
if(mb_strlen($name) < 3 || mb_strlen($name) > 50) {
    echo "Недопустимая длина имени";
    exit();
} else if(mb_strlen($message) < 3) {
    echo "Недопустимая длина сообщения";
    exit();
}

// Подключение к базе данных
$mysql = new mysqli('localhost', 'root', 'root', 'fb');

if ($mysql->connect_error) {
    die('Ошибка подключения (' . $mysql->connect_errno . ') ' . $mysql->connect_error);
}

// Вставка данных в базу данных
$stmt = $mysql->prepare("INSERT INTO `ms` (`name`, `email`, `message`) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $name, $email, $message);
$stmt->execute();
$stmt->close();

// Извлечение данных из базы данных
$result = $mysql->query("SELECT `name`, `email`, `message` FROM `ms`");
$feedbacks = [];
while ($row = $result->fetch_assoc()) {
    $feedbacks[] = $row;
}
$mysql->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../styles.css">
    <title>Обратная связь</title>
</head>
<body>
    <header>
        <h1>Обратная связь</h1>
        <nav>
            <ul>
                <li><a href="../index.html">Главная</a></li>
                <li><a href="series.html">Сериалы</a></li>
                <li><a href="feedback.html">Обратная связь</a></li>
                <li><a href="../todo.html">ToDo List</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <h2>Оставьте ваш отзыв</h2>
        <form action="check.php" method="post">
            <label for="name">Имя:</label>
            <input type="text" id="name" name="name" required>
            
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
            
            <label for="message">Сообщение:</label>
            <textarea id="message" name="message" rows="4" required></textarea>
            
            <button type="submit">Отправить</button>            
        </form>
        
        <h2>Отзывы</h2>
        <div id="feedback-container">
            <?php if (count($feedbacks) > 0): ?>
                <?php foreach ($feedbacks as $fb): ?>
                    <div class="feedback">
                        <h3><?php echo htmlspecialchars($fb['name']); ?></h3>
                        <p><?php echo htmlspecialchars($fb['email']); ?></p>
                        <p><?php echo htmlspecialchars($fb['message']); ?></p>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>Нет сообщений.</p>
            <?php endif; ?>
        </div>
    </main>
    <footer>
        <p>&copy; 2024 Каталог сериалов</p>
    </footer>
</body>
</html>
